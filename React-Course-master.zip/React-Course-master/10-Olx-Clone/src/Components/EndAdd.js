import React from 'react'

export default function EndAdd() {
    return (
        <div>
            <img className='endimg' src="https://i.pinimg.com/originals/c6/b7/8e/c6b78ed22b30a8230f5ccea2ddc88468.jpg" alt="..." />
        </div>
    )
}
