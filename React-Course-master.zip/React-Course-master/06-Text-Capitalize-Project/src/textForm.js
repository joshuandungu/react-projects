import React from 'react'

export default function textForm() {
  return (
    <div>
     
<div class="mb-3">
  <label for="textbox" className="form-label">Example textarea</label>
  <textarea className="form-control" id="textbox" rows="3"></textarea>
</div>
    </div>
  )
}
