import React from 'react';
import './App.css';
import ApiHandelingScreen from './Api/ApiHandelingScreen';

function App() {
  return (
    <>
      <ApiHandelingScreen/>
    </>
  );
}

export default App;
