import React from 'react'
import './Demo.css'

export default function Demo() {
    return (
        <div className='m-o'>
            <h1>Pellentesque suscipit <br />
                fringilla libero eu.</h1>
            <button>Get a Demo &#x2192;</button>
        </div>
    )
}
