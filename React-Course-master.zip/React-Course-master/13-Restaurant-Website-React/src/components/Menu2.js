import React from 'react';
import Menu2Text from './Menu2Text';
function Menu2() {
    return(
    <div>
        <br />
        <Menu2Text />
        <Menu2Text />
        <Menu2Text />
        <Menu2Text />
        <Menu2Text />
        <Menu2Text />
        <Menu2Text />
        <Menu2Text />
    </div>
    );
}
export default Menu2;