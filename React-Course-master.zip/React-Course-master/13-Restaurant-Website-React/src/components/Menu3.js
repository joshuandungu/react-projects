import React from 'react';
import Menu3Text from './Menu3Text';
function Menu3() {
    return(
    <div>
        <br />
        <Menu3Text />
        <Menu3Text />
        <Menu3Text />
        <Menu3Text />
        <Menu3Text />
        <Menu3Text />
        <Menu3Text />
        <Menu3Text />
    </div>
    );
}
export default Menu3;