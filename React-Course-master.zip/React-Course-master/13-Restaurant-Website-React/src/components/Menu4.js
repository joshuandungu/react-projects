import React from 'react';
import Menu4Text from './Menu4Text';
function Menu4() {
    return(
    <div>
        <br />
        <Menu4Text />
        <Menu4Text />
        <Menu4Text />
        <Menu4Text />
        <Menu4Text />
        <Menu4Text />
        <Menu4Text />
        <Menu4Text />
    </div>
    );
}
export default Menu4;