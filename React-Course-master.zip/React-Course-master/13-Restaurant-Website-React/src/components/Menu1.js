import React from 'react';
import Menu1Text from './Menu1Text';
function Menu1() {
    return(
    <div>
        <br />
        <Menu1Text />
        <Menu1Text />
        <Menu1Text />
        <Menu1Text />
        <Menu1Text />
        <Menu1Text />
        <Menu1Text />
        <Menu1Text />
    </div>
    );
}
export default Menu1;