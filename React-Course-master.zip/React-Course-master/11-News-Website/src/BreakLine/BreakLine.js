import React from 'react'
import './BreakLine.css';


export default function BreakLine() {
    return (
        <div>
            <div className='breakline'></div>
        </div>
    )
}
