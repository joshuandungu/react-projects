

```
switcher.addEventListener('click', function() {  
    document.body.classList.toggle('dark-theme')
}); 

```


### Light_Mode
![image](https://user-images.githubusercontent.com/67835881/124374752-96af5480-dcbb-11eb-8a00-3034ea93537d.png)


### Dark_mode
![image](https://user-images.githubusercontent.com/67835881/124374824-ee4dc000-dcbb-11eb-877f-3132ffdf7266.png)
