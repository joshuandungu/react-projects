##  Project-Based-Learning💻

![image](https://user-images.githubusercontent.com/67835881/126779554-732e5a96-c38c-4109-a6bd-88400a69961d.png)


<!--  |  project Name  | [source-code]() | [Demo]() | |  --->
## CSS3 Project-Lists ✨


| Project Name | Source-Code |   Demo   | Descriptions |
| --- | --- | --- | --- |
| Build a Tribute Page | [Click](https://github.com/Aj7t/Project-Based-Learning/tree/main/CSS3/Tribute%20Page) |   [Demo](https://codepen.io/aj7t/full/poPvKaW)  |created a tribute webpage with proper use of symantic tages, HTML Text Formatting and some basic CSS3 |
| Buid a Survey Form | [Click](https://github.com/Aj7t/Project-Based-Learning/tree/main/CSS3/Survey%20Form) | [Demo](https://codepen.io/aj7t/full/zYwxjXE) | HTML Form  and  beautiful design to Form layout using CSS3 |



## JS projectLists

| Project Name | Source-Code |   Demo   | Descriptions |
| --- | --- | --- | --- | 
| Text Editor (synonyms)  | [Click](https://github.com/Aj7t/Project-Based-Learning/tree/main/JS-ES6/Text%20editor) | [Demo](http://aj7t.me/Project-Based-Learning/JS-ES6/Text%20editor/) | Build a plugin on top of the TinyMCE rich text editor, with synonyms plugins intergrated into text-edior |
  
