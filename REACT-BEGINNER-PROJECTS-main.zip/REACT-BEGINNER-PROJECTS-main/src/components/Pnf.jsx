import React from 'react'
import { Col, Container, Row } from 'react-bootstrap'

const Pnf = () => {
  return (
    <Container className='my-5'>
        <Row>
            <Col>
            <h1 className="display-5 text-center text-danger p-3">Page Not Found..!</h1>
            </Col>
        </Row>
    </Container>
  )
}

export default Pnf