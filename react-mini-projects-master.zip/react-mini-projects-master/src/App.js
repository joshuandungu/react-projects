import './App.css';
import BMICalculator from './BMICalcalator/BMICalculator';
import EMICalculator from './EMICalculator/EMICalculator';
import FilterCard from './Filter/FilterCard';
import GithubSearch from './GitHubUserSearch/GitHubSearch';
import ColorGenerator from './RandomColorGenerator/ColorGenerator';
import TextEditor from './TextEditor/TextEditor';

function App() {
  return (
    <>
      {/* <your-component /> */}
    </>
  );
}

export default App;