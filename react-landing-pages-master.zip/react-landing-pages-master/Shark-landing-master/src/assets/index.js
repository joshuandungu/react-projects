import slider1 from "./slider1.png";
import slider2 from "./slider2.png";
import slider3 from "./slider3.png";
import slider4 from "./slider4.png";
import logo from "./logo.png";
import traitsGridImg from "./traitsGridImg.png";
import gun from "./gun.png";
import communityImg from "./communityImg.png";
import footer_logo from "./footer_logo.png";
import hamburger from "./hamburger.png";
import closeburger from "./closeburger.png";
import arrowRight from "./arrowRight.png";
import video from "./Video.png";

export {
  slider1,
  slider2,
  slider3,
  slider4,
  traitsGridImg,
  gun,
  communityImg,
  logo,
  footer_logo,
  hamburger,
  arrowRight,
  closeburger,
  video,
};
