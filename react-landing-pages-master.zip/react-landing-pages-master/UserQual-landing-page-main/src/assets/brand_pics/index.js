import brand_1 from "./Kelloggs_logo.png";
import brand_2 from "./Mac_logo.png";
import brand_3 from "./Macys_logo.png";
import brand_4 from "./Philips_logo.png";
import brand_5 from "./Poshmark_logo.png";

export { brand_1, brand_2, brand_3, brand_4, brand_5 };
