import a from "./a.png";
import b from "./b.png";
import c from "./c.png";
import d from "./d.png";
import e from "./e.png";
import f from "./f.png";
import laptop from "./laptop.png";
import video from './videos/business.mp4'

export { a, b, c, d, e, f ,laptop,video};
