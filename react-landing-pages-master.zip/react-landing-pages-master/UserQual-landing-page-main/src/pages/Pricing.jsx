import React from 'react'

const Pricing = () => {
    return (
        <div>
            Pricing

        </div>
    )
}

export default Pricing
