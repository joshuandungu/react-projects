import React from 'react'

const Tester = () => {
    return (
        <div>
            TESTER
        </div>
    )
}

export default Tester
