import HeaderLogo from "./headerLogo.png";
import MainBg from "./main-bg.png";
import john from "./john_sales.jpeg";
import anton from "./anton_tech.jpeg";
import hostsBg from "./hosts-bg.png";
import faqsRight from "./faqs-right.png";
import faqsImage from "./faqs-image.png";
import footerLogo from "./footer-logo.png";

export {
  footerLogo,
  HeaderLogo,
  MainBg,
  john,
  anton,
  hostsBg,
  faqsRight,
  faqsImage,
};
