This repository showcases a couple of frontend projects developed for clients. Each project demonstrates a unique set of skills and technologies used to meet the client's requirements.

#### Most of the stack used:
- Html/css/js
- Reactjs
- SASS/SCSS
- AOS Library
- SwiperJS

<img width="1440" alt="Screenshot 2023-04-05 at 9 40 05 PM" src="https://user-images.githubusercontent.com/37541648/230147874-082e5192-4e4a-4a08-a748-b59d5b9993ee.png">
