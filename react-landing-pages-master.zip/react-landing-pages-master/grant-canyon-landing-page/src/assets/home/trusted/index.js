import t1 from "./t1.png";
import t2 from "./t2.png";
import t3 from "./t3.png";
import t4 from "./t4.png";
import t5 from "./t5.png";
import t6 from "./t6.png";
import t7 from "./t7.png";

export { t1, t2, t3, t4, t5, t6, t7 };
