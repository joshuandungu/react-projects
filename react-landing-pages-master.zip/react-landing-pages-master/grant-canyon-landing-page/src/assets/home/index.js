import funds_1 from "./funds_1.png";
import funds_2 from "./funds_2.png";
import funds_3 from "./funds_3.png";
import funds_4 from "./funds_4.png";
import funds_5 from "./funds_5.png";
import funds_6 from "./funds_6.png";
import funds_7 from "./funds_7.png";
import funds_8 from "./funds_8.png";
import front_world from "./front_world.png";
import logo from "./logo.jpg";
import quiz_illustration from "./quiz_illustration.png";
import quiz_bg from "./quiz_bg.png";
import discover_1 from "./discover_1.png";
import discover_2 from "./discover_2.png";
import discover_3 from "./discover_3.png";
import how_1 from "./how_1.png";
import how_2 from "./how_2.png";
import how_3 from "./how_3.png";
import how_4 from "./how_4.png";
import news_2 from "./news_2.png";
import news_3 from "./news_3.png";
import news_4 from "./news_4.png";
import news_5 from "./news_5.png";
import logo_2 from "./logo_2.png";

export {
  funds_1,
  funds_2,
  funds_3,
  funds_4,
  funds_5,
  funds_6,
  funds_7,
  funds_8,
  front_world,
  logo,
  logo_2,
  quiz_illustration,
  quiz_bg,
  discover_1,
  discover_2,
  discover_3,
  how_1,
  how_2,
  how_3,
  how_4,
  news_2,
  news_3,
  news_4,
  news_5,
};
