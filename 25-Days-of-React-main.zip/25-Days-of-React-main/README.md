<div align="center">
<img  height="100%"  src="https://i.ibb.co/xHcKscf/E-Pushparaj.jpg" />
</div>

<div align="center">

  <h1>Day - 25 in React</h1>
  <a class="header-badge" target="_blank" href="https://www.linkedin.com/in/coding-ranjith-97b6ab238">
  <img src="https://img.shields.io/badge/style--5eba00.svg?label=LinkedIn&logo=linkedin&style=social">
  </a>

  <a class="header-badge" target="_blank" href="https://youtube.com/@coding-ranjith">
  <img src="https://img.shields.io/badge/style--5eba00.svg?label=Youtube&logo=youtube&style=social">
  </a>

<sub>Author: <a href="https://www.linkedin.com/in/coding-ranjith-97b6ab238" target="_blank">Coding Ranjith</a> & <a href="https://www.linkedin.com/in/pushparajraje/" target="_blank">Pushparaj Raje</a><br>
</sub>
<small> August to September, 2023</small>

</div>


- Day 2: JSX syntax, rendering elements, and understanding components. 
  - [Explore JSX syntax.](#jsx-syntax)
  - [Create and render React elements.](#setup)
  - [Understand the component structure.](#first-react-app)
 
    
--- 

## JSX syntax

### Explore JSX syntax.





[Day 2 >>]()


❤️👨‍💻❤️ HAPPY CODING ❤️😇❤️






