<div align="center">
<img  height="100%"  src="https://i.ibb.co/WxJdF0b/react-logo.png" />
</div>

<div align="center">

  <h1>Day - 06 in React</h1>
  <a class="header-badge" target="_blank" href="https://www.linkedin.com/in/coding-ranjith-97b6ab238">
  <img src="https://img.shields.io/badge/style--5eba00.svg?label=LinkedIn&logo=linkedin&style=social">
  </a>

  <a class="header-badge" target="_blank" href="https://youtube.com/@coding-ranjith">
  <img src="https://img.shields.io/badge/style--5eba00.svg?label=Youtube&logo=youtube&style=social">
  </a>

<sub>Author: <a href="https://www.linkedin.com/in/coding-ranjith-97b6ab238" target="_blank">Coding Ranjith</a> & <a href="https://www.linkedin.com/in/pushparajraje/" target="_blank">Pushparaj Raje</a>
</sub><br>
<small> August to September, 2023</small></sub>

</div>

Styling in React (CSS, CSS-in-JS libraries).
 - [Explore different approaches to styling React components](#style-react-components)
 - [Practice styling using CSS or CSS-in-JS libraries like Styled Components](#css-js-libraries)

    
--- 

## Style React Components

### Explore different approaches to styling React components

---

## CSS JS Libraries

### Practice styling using CSS or CSS-in-JS libraries like Styled Components

---


[Day 7 >>]()


❤️👨‍💻❤️ HAPPY CODING ❤️😇❤️






