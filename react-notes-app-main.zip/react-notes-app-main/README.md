# React Notes App

## Preview

https://user-images.githubusercontent.com/93486013/185519764-1fa25f50-c088-4b27-a4c7-595aba5e2a8e.mp4



<!--
### Features :
- can add add your note with Theme color of your choice.
- can delete your note
- can update the text of your note
- can lock/unlock your note (to prevent accidental change)
-->
