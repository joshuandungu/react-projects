## Flint.money Clone
- Tech used: React, React Router & Chakra UI.
- Cloned the UI of Home Page & About us Page.
- Website is responsive.

### Preview
[![Flint-dot-money clone]](https://user-images.githubusercontent.com/93486013/188429136-b1ecad16-db93-48d1-a2cc-8b1f30069b2b.mp4)
