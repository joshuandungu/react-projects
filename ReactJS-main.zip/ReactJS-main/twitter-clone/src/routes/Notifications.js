const Notifications = () => {
  return <div>Notifications</div>;
};

export default Notifications;
