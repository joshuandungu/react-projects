const Lists = () => {
  return <div>Lists</div>;
};

export default Lists;
