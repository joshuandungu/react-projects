export const HOME = "/home";
export const EXPLORE = "/explore";
export const NOTIFICATIONS = "/notifications";
export const MESSAGES = "/messages";
export const BOOKMARKS = "/bookmarks";
export const LISTS = "/lists";
export const PROFILE = "/profile";
