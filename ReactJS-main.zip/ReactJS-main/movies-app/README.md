# Movies App

Movies app using [IMDb API](https://imdb-api.com/api).  
[Live demo](https://mhmdali102-movies-app.netlify.app)
