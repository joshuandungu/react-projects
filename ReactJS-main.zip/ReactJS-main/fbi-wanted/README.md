# FBI Wanted

FBI WANTED using [FBI Wanted API](https://www.fbi.gov/wanted/api).  
[Live demo](https://mhmdali102-fbi-wanted.netlify.app/)
