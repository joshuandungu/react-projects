# TODO APP

Simple CRUD TODO List App with React and Bootstrap.  
[Live Demo](https://mhmdali102-todo-list.netlify.app/)