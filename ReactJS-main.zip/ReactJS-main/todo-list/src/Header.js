function Header() {
    return (
        <header>
            <h1 className="py-2 text-center bg-dark text-light">TODO List</h1>
        </header>
    )
}

export default Header;
