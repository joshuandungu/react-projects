import Header from "./Header";

function App() {
  return <Header />;
}

export default App;
