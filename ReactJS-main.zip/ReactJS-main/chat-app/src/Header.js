const Header = () => {
  return <header>Header</header>;
};

export default Header;