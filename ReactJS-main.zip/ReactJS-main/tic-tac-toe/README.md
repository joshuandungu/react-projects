# tic-tac-toe game with React

This game is the tutorial from the [official documentation of React](https://reactjs.org/tutorial).