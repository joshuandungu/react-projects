const Start = (endpointTitle) => {
    return <div>
        <p>{"{"}</p>
        <span className="ms-4">"</span>
        <input type="text" name="entity" className="form-control d-inline-block my-2 ms-2 w-25 ps-2" placeholder="Entitiy title" value={endpointTitle} onChange={()=>{}}/>
        <span className="ms-2">"</span>
        <span className="ms-3">:</span>
        <span className="ms-3">{"{"}</span>
        <br />
    </div>
}

export default Start;