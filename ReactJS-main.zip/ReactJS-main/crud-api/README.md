# CRUD API
With the help of this web app you caxn use the [crudcrud.com](https://crudcrud.com/) API without writing a single line of code.

# Status
This web app still under development stages, but you can check the [live demo].

# About
This is an [Open source](https://github.com/mhmdali102/ReactJS/tree/main/crud-api) app, build by [Mhmd Ali Hsen](https://github.com/mhmdali102) with [ReactJS](https://reactjs.org/) & [Bootstrap 5](https://getbootstrap.com/)

# License
This project is licensed under the [MIT](https://opensource.org/licenses/MIT) License - see the [LICENSE](https://github.com/mhmdali102/ReactJS/blob/main/LICENSE) file for details.