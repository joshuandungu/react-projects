const categories = ["Groceries", "Utilities", "Entertainment"] as const;

export default categories;
