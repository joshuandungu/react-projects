export const CACHE_KEY_TODOS = ["todos"];
