import TaskList from "./tasks/TaskList";

const HomePage = () => {
  return <TaskList />;
};

export default HomePage;
