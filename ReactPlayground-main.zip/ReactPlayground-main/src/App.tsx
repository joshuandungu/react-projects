import "./App.css";
import Zustand from "./zustand/Zustand";

function App() {
  return (
    <div>
      {/* <ExpenseTracker /> */}
      {/* <ReactQuery /> */}
      {/* <StateManagement /> */}
      <Zustand />
    </div>
  );
}

export default App;
