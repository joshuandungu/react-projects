import MainSection from '../Compoenents/MainSection'

const Home = () => {
  return (
    <>
       <MainSection />
    </>
  )
}

export default Home