// const cartReducer = (state, action) => {
//   if(action.type === 'ADD_TO_CARD') {
//     let { id, name, price } = action.payload;
//   }
//     return {
//         ...state,
//         cart: [],
//     };
// }

// export default cartReducer