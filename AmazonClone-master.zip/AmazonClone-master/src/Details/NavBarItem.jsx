const NavBarItem = [
    {
        id:1,
        MenuItem: 'Amazon miniTV'
    },
    {
        id:2,
        MenuItem: 'Sell'
    },
    {
        id:3,
        MenuItem: 'Best Sellers'
    },
    {
        id:4,
        MenuItem: 'Mobiles'
    },
    {
        id:5,
        MenuItem: 'Today Deals'
    },
    {
        id:6,
        MenuItem: 'Customer Service'
    },
    {
        id:7,
        MenuItem: ' Electronics'
    },
    {
        id:8,
        MenuItem: 'Prime'
    },
    {
        id:9,
        MenuItem: 'New Releases'
    },
    {
        id:10,
        MenuItem: 'Home & Kitchen'
    },
    {
        id:11,
        MenuItem: 'Amazon Pay'
    },
    {
        id:12,
        MenuItem: 'Fashion'
    },
    {
        id:13,
        MenuItem: 'Computers'
    },
    {
        id:14,
        MenuItem: 'Beauty & Personal Care'
    },
]

export default NavBarItem;