export const LeftBarItem = [
  {
    id: 1,
    menuItem: "Echo & Alexa",
  },
  {
    id: 2,
    menuItem: "Fire TV",
  },
  {
    id: 3,
    menuItem: "Kindle E-Readers & eBooks",
  },
  {
    id: 4,
    menuItem: "Audible Audiobooks",
  },
  {
    id: 5,
    menuItem: "Amazon Prime Video",
  },
  {
    id: 6,
    menuItem: "Kindle E-Readers & eBooks",
  },
  {
    id: 7,
    menuItem: "Amazon Prime Music",
  },
];

export const shopByCategory = [
    {
        id: 1,
        menuItem: "Mobiles, Computers",
      },
      {
        id: 2,
        menuItem: "TV, Appliances, Electronics",
      },
      {
        id: 3,
        menuItem: "Men's Fashion",
      },
      {
        id: 4,
        menuItem: "Women's Fashion",
      },
]

export const ProgramsFeatures = [
    {
        id:1,
        menuItem: 'Gift Cards & Mobile Recharges',
    },
    {
        id:2,
        menuItem: 'Flight Tickets',
    },
    {
        id:3,
        menuItem: 'Clearance store',
    },
]

export const Trending = [
    {
        id: 1,
        menuItem: 'Best Sellers'
    },
    {
        id: 2,
        menuItem: 'New Releases'
    },
    {
        id: 3,
        menuItem: 'Movers and Shakers'
    },
]

