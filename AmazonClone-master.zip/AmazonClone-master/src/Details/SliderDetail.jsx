export const TodaysDeals = [
    {
        id: 1,
        productImage: 'p1',
        productName: 'Samsung Galaxy M14 5G'
    },
    {
        id: 2,
        productImage: 'p2',
        productName: 'boAt New ANC Headphone Launch - R…'
    },
    {
        id: 3,
        productImage: 'p3',
        productName: 'Blockbuster Deals on Speakers, Sound…'
    },
    {
        id: 4,
        productImage: 'p4',
        productName: 'Compact Powerbank at 999 - Limited…'
    },
    {
        id: 5,
        productImage: 'p5',
        productName: 'Apple Airpods starting Rs. 11999'
    },
    {
        id: 6,
        productImage: 'p6',
        productName: 'Deal of the Day on Nobel Hygiene'
    },
    {
        id: 7,
        productImage: 'p7',
        productName: 'Never before prices on Mivi Headsets'
    },
    {
        id: 8,
        productImage: 'p8',
        productName: 'Crazy Offers on Noise Headphones'
    },
    {
        id: 9,
        productImage: 'p9',
        productName: 'Best Deals on Trolley and Backpack fr…'
    },
    {
        id: 10,
        productImage: 'p10',
        productName: 'Dry Fruits and Seeds'
    },
]