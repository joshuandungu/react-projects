export const GettoKnowUs = [
    { id: 1, item1:'About Us' },
    { id: 2, item1:'Careers' },
    { id: 3, item1:'Press Releases' },
    { id: 4, item1:'Amazon Science' },
]

export const ConnectwithUs = [
    { id: 1, item1:'Facebook' },
    { id: 2, item1:'Twitter' },
    { id: 3, item1:'Instagram' },
]

export const MakeMoneywithUs = [
    { id: 1, item1:'Sell on Amazon' },
    { id: 2, item1:'Sell under Amazon Accelerator' },
    { id: 3, item1:'Protect and Build Your Brand' },
    { id: 4, item1:'Amazon Global Selling' },
    { id: 5, item1:'Become an Affiliate' },
    { id: 6, item1:'Fulfilment by Amazon' },
    { id: 7, item1:'Advertise Your Products' },
    { id: 8, item1:'Amazon Pay on Merchants' },
]

export const LetUsHelpYou = [
    { id: 1, item1:'COVID-19 and Amazon' },
    { id: 2, item1:'Your Account' },
    { id: 3, item1:'Returns Centre' },
    { id: 4, item1:'100% Purchase Protection' },
    { id: 5, item1:'Amazon App Download' },
    { id: 6, item1:'Help' },
]