const IconTMDB = () => {
  return <img src="/TMDB.svg" width="123" alt="TMDB" />;
};

export default IconTMDB;
