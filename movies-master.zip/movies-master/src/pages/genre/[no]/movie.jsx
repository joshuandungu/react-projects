import MediaComponent from "@/pages";

const Movies = () => {
  return (
    <>
      <title>Movies · React Movies</title>
      <MediaComponent />
    </>
  );
};

export default Movies;
