import MediaComponent from "@/pages";

const TVShows = () => {
  return (
    <>
      <title> TV Shows · React Movies</title>
      <MediaComponent />
    </>
  );
};

export default TVShows;
