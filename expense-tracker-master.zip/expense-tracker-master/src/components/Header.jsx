import React from 'react'

function Header() {
  return <h2 className='header'>Expense Tracker</h2>;
}

export default Header