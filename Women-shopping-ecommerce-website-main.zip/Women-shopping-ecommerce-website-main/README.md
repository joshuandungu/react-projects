Home Page :
![image](https://github.com/vibedguy/Women-shopping/assets/118599093/44476acc-fcf8-4f84-80dd-8e8172d7ca66)

Product category page :
![image](https://github.com/vibedguy/Women-shopping/assets/118599093/547121a5-10fc-4533-97ba-7ccdfa737e50)

Product page :
![image](https://github.com/vibedguy/Women-shopping/assets/118599093/8cee2acd-37a0-45a5-958f-27ae5959de8f)

Cart page :
![image](https://github.com/vibedguy/Women-shopping/assets/118599093/be581c9b-f86e-4714-9887-860f5d9a4156)

![image](https://github.com/vibedguy/Women-shopping/assets/118599093/acbaae12-3274-4bda-802d-9ae2a4509cdb)

Checkout page :
![image](https://github.com/vibedguy/Women-shopping/assets/118599093/861b9b29-be3e-4666-b8f9-cd8b1adb216c)

![image](https://github.com/vibedguy/Women-shopping/assets/118599093/4b8986c5-88ae-4e68-b8c7-6bfbb65f2bc7)

![image](https://github.com/vibedguy/Women-shopping/assets/118599093/8377aff3-77d3-4714-8775-34d204b25b8c)

![image](https://github.com/vibedguy/Women-shopping/assets/118599093/d5b76e81-2a8b-41e8-9017-a72eb5620d50)
