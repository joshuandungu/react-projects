const SuccessMessage = () => {
  return (
    <section className="success-alert">
      <p>successfully added to cart!</p>
    </section>
  );
}

export default SuccessMessage;
