// eslint-disable-next-line no-undef
export const IS_DEVELOPMENT = process.env.NODE_ENV !== "production"