##### :black_small_square: React-projects

<p>
&nbsp;&nbsp;:small_orange_diamond: <a href="/1-base-64-encode-decode"><b>Base64 encode / decode</b></a> - Encode or decode from Base64 format<br>
&nbsp;&nbsp;:small_orange_diamond: <a href="/2-suggest-a-movie"><b>Suggest a movie</b></a> - Random movie suggestion from a json file<br>
&nbsp;&nbsp;:small_orange_diamond: <a href="/3-rubik-timer"><b>Rubik timer</b></a> - Rubik's Cube speedsolving timer with simple scrambler<br>
&nbsp;&nbsp;:small_orange_diamond: <a href="/4-rock-paper-scissors"><b>Rock paper scissors</b></a> - Classic rock-paper-scissors game<br>
</p>
