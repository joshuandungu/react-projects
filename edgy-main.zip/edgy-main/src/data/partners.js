const partners = [
    {
        id: 0,
        name: 'AirBNB',
        img: "https://img.icons8.com/?size=512&id=103424&format=png",
        href: 'https://www.airbnb.com/'
    },
    {
        id: 1,
        name: 'Duolingo',
        img: 'https://img.icons8.com/?size=512&id=jJS472JMXlsE&format=png',
        href: 'https://www.duolingo.com/'
    },
    {
        id: 2,
        name: 'FinalCut',
        img: 'https://img.icons8.com/?size=512&id=9vdP7gCiMiAA&format=png',
        href: 'https://www.apple.com/final-cut-pro/'
    },
    {
        id: 3,
        name: 'Fiverr',
        img: 'https://img.icons8.com/?size=512&id=ngc6JsBomclm&format=png',
        href: 'https://www.fiverr.com/'
    },
    {
        id: 4,
        name: 'Figma',
        img: 'https://img.icons8.com/?size=512&id=zfHRZ6i1Wg0U&format=png',
        href: 'https://www.figma.com/'
    },
]

export default partners