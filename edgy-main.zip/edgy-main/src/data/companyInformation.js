const companyInformation = [
    { label: "Founded", value: "2022" },
    { label: "Employees", value: "200" },
    { label: "Beta Users", value: "521" },
    { label: "Raised", value: "$25M" },
];

export default companyInformation;