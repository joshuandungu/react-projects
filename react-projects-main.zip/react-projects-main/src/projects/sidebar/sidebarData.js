export const sidebarLinks = [
    {
        id: 1,
        link: "My Orders",
        path: "/",
    },
    {
        id: 2,
        link: "My Account",
        path: "/",
    },
    {
        id: 3,
        link: "Order Tracking",
        path: "/",
    },
    {
        id: 4,
        link: "Help & Support",
        path: "/",
    },
];


export const dropdownLinks = [
    {
        id: 1,
        link: "Cameras",
        path: "/",
    },
    {
        id: 2,
        link: "Mobiles",
        path: "/",
    },
    {
        id: 3,
        link: "LEDs",
        path: "/",
    },
    {
        id: 4,
        link: "Laptops",
        path: "/",
    },
];