const galleryData = [
    {
        id: 1,
        img: "https://cdn.pixabay.com/photo/2016/12/13/22/25/bird-1905255__340.jpg",
        category: "birds",
    },
    {
        id: 2,
        img: "https://cdn.pixabay.com/photo/2015/04/19/08/33/flower-729512_960_720.jpg",
        category: "flowers",
    },
    {
        id: 3,
        img: "https://cdn.pixabay.com/photo/2016/12/05/11/39/fox-1883658__340.jpg",
        category: "animals",
    },
    {
        id: 4,
        img: "https://cdn.pixabay.com/photo/2016/10/25/12/28/iceland-1768744__340.jpg",
        category: "waterfalls",
    },
    {
        id: 5,
        img: "https://cdn.pixabay.com/photo/2012/02/24/16/59/swan-16736__340.jpg",
        category: "birds",
    },
    {
        id: 6,
        img: "https://cdn.pixabay.com/photo/2015/10/09/00/55/lotus-978659_960_720.jpg",
        category: "flowers",
    },
    {
        id: 7,
        img: "https://cdn.pixabay.com/photo/2016/11/29/10/07/tiger-1868911__340.jpg",
        category: "animals",
    },
    {
        id: 8,
        img: "https://cdn.pixabay.com/photo/2019/06/08/11/17/waterfall-4259935__340.jpg",
        category: "waterfalls",
    },
    {
        id: 9,
        img: "https://cdn.pixabay.com/photo/2020/07/01/15/29/landscape-5359998__340.jpg",
        category: "waterfalls",
    },
    {
        id: 10,
        img: "https://cdn.pixabay.com/photo/2013/07/21/13/00/rose-165819_960_720.jpg",
        category: "flowers",
    },
    {
        id: 11,
        img: "https://cdn.pixabay.com/photo/2014/05/11/13/39/bird-341898__340.jpg",
        category: "birds",
    },
    {
        id: 12,
        img: "https://cdn.pixabay.com/photo/2020/05/03/18/49/baby-elephant-5126326__340.jpg",
        category: "animals",
    },
];

export default galleryData;