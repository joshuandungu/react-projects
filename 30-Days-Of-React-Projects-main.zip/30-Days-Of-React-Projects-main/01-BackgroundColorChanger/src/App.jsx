import BackgroundColorChanger from "./components/BackgroundColorChanger";

const App = () => {
  return (
    <>
      <BackgroundColorChanger />
    </>
  );
};

export default App;
