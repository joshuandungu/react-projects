### [netflix.com](https://mininetflix.netlify.app/)
<img src="https://i.ibb.co/zFdNZDq/Oneview.png" alt="netflix.com UI Clone Oneview" width="100%" />
