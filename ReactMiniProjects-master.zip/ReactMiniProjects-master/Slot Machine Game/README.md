### [Slot Machine Game](https://slotsmachinegame.netlify.app/)
<img src="https://i.ibb.co/pJHd9hT/Oneview.png" alt="Slot Machine Game Oneview" width="100%" />
