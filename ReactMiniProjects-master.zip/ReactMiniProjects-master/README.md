### [Calculator](https://friendlycalculator.netlify.app/)
<img src="https://i.ibb.co/4j8XJsp/Oneview-Two.png" alt="Calculator Oneview" width="100%" />

### [Greeting Website](https://greetingswebsite.netlify.app/)
<img src="https://i.ibb.co/WKSXSG6/Oneview.png" alt="Greeting Website Oneview" width="100%" />

### [Slot Machine Game](https://slotsmachinegame.netlify.app/)
<img src="https://i.ibb.co/pJHd9hT/Oneview.png" alt="Slot Machine Game Oneview" width="100%" />

### [ToDoList](https://friendlytodolist.netlify.app/)
<img src="https://i.ibb.co/fN4tfPJ/Oneview.png" alt="ToDoList Oneview" width="100%" />

### [netflix.com](https://mininetflix.netlify.app/)
<img src="https://i.ibb.co/zFdNZDq/Oneview.png" alt="netflix.com UI Clone Oneview" width="100%" />
