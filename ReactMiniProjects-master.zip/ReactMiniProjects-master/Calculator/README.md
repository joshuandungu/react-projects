### [Calculator](https://friendlycalculator.netlify.app/)
<img src="https://i.ibb.co/4j8XJsp/Oneview-Two.png" alt="Calculator Oneview" width="100%" />
