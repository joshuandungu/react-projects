import React from 'react'

function Success() {
  return (
    <div>Successfully paid</div>
  )
}

export default Success