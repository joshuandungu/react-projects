import image1 from "../assets/image1.png";
import image2 from "../assets/image1.png";
import image3 from "../assets/image1.png";

export const singleListingData = {
    id: 1,
    title: "Plaid Sleeve Kangaroo Pocket Drawstring Hoodie",
    imageFile: [
        {
            id: 1,
            title: "laptop Image",
            img: image1,
        },
        {
            id: 1,
            title: "laptop Image",
            img: image2,
        },
        {
            id: 1,
            title: "laptop Image",
            img: image3,
        },
        {
            id: 1,
            title: "laptop Image",
            img: image1,
        },
    ],
    description:
        "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. ",
};
